<?php
session_start();
require_once 'tomato_db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$username = htmlspecialchars($_SESSION['username'] ?? 'User', ENT_QUOTES, 'UTF-8');
$role     = htmlspecialchars($_SESSION['role'] ?? 'admin', ENT_QUOTES, 'UTF-8');
$active_page = 'scheduling';

$preselect_date = '';
if (!empty($_GET['date']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date'])) {
    $preselect_date = htmlspecialchars($_GET['date']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Scheduling — Tomato Cultivation System</title>

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;0,800;1,400;1,600&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Fira+Code:wght@300;400;500&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <link rel="stylesheet" href="css/schedule.css">
  <script src="notifications.js"></script>

</head>
<body>
<div class="layout">

  <?php include 'sidebar.php'; ?>

  <div class="main">
    <div class="topbar">
      <div class="topbar-title"><i class="fas fa-calendar-days"></i> Farm Scheduling</div>
      <div class="topbar-clock" id="clock">—</div>
    </div>

    <div class="page-content">

      <div class="page-hero" style="margin-bottom:28px;">
        <div class="page-hero-badge"><i class="fas fa-calendar-check" style="margin-right:6px;"></i>Irrigation &amp; Spray Planner</div>
        <h1>Farm <span>Schedule</span></h1>
        <p>Plan and manage irrigation cycles, pesticide spraying, harvests, and maintenance tasks. Click any date to add or edit scheduled tasks.</p>
      </div>

      <div class="sched-layout">

        <div class="cal-col">

          <!-- CALENDAR -->
          <div class="cal-card">
            <div class="cal-header">
              <div class="cal-month-label" id="cal-month-label">March 2026</div>
              <div class="cal-nav-btns">
                <button class="cal-nav-btn today-btn" onclick="goToday()">Today</button>
                <button class="cal-nav-btn" onclick="changeMonth(-1)"><i class="fas fa-chevron-left"></i></button>
                <button class="cal-nav-btn" onclick="changeMonth(1)"><i class="fas fa-chevron-right"></i></button>
              </div>
            </div>
            <div class="cal-body">
              <div class="cal-weekdays">
                <div class="cal-wd">Sun</div><div class="cal-wd">Mon</div><div class="cal-wd">Tue</div>
                <div class="cal-wd">Wed</div><div class="cal-wd">Thu</div><div class="cal-wd">Fri</div><div class="cal-wd">Sat</div>
              </div>
              <div class="cal-days-grid" id="cal-days-grid"></div>
            </div>
            <div class="cal-legend">
              <div class="legend-item"><div class="legend-dot" style="background:var(--water);"></div> Irrigation</div>
              <div class="legend-item"><div class="legend-dot" style="background:var(--solar);"></div> Spraying</div>
              <div class="legend-item"><div class="legend-dot" style="background:var(--red);"></div> Harvest</div>
              <div class="legend-item"><div class="legend-dot" style="background:var(--green-mid);"></div> Maintenance</div>
              <div class="legend-item" style="margin-left:auto;font-family:var(--font-mono);font-size:0.7rem;"><i class="fas fa-circle-plus" style="margin-right:4px;color:var(--green-mid);"></i> Click date to add</div>
            </div>
          </div>

          <!-- UPCOMING TASKS -->
          <div class="detail-card">
            <div class="detail-head">
              <div class="detail-head-icon" style="background:var(--water-pale);color:var(--water);"><i class="fas fa-list-check"></i></div>
              <div>
                <div class="detail-title">Upcoming Tasks</div>
                <div class="detail-subtitle" id="upcoming-count">Next 14 days</div>
              </div>
            </div>
            <div class="detail-body" id="upcoming-list"></div>
          </div>

        </div>

        <!-- DETAIL PANEL -->
        <div class="detail-panel">

          <!-- Selected day events -->
          <div class="detail-card">
            <div class="detail-head">
              <div class="detail-head-icon" style="background:var(--green-pale);color:var(--green-mid);"><i class="fas fa-calendar-day"></i></div>
              <div>
                <div class="detail-title" id="selected-day-label">Select a date</div>
                <div class="detail-subtitle" id="selected-day-count">Click a date to see tasks</div>
              </div>
            </div>
            <div class="detail-body">
              <div id="day-events-list">
                <div class="empty-state">
                  <div class="empty-icon">📅</div>
                  <div class="empty-title">No date selected</div>
                  <div class="empty-desc">Click any date on the calendar to view and manage tasks</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Add Event Form -->
          <div class="detail-card">
            <div class="detail-head">
              <div class="detail-head-icon" style="background:var(--solar-pale);color:var(--solar);"><i class="fas fa-plus"></i></div>
              <div>
                <div class="detail-title">Add New Task</div>
                <div class="detail-subtitle" id="add-form-date-label">Select a date first</div>
              </div>
            </div>
            <div class="detail-body">
              <div class="form-group">
                <label class="form-label">Task Type</label>
                <div class="type-selector">
                  <button class="type-btn" onclick="selectType('irrigation')" id="type-irrigation"><i class="fas fa-droplet"></i> Irrigation</button>
                  <button class="type-btn" onclick="selectType('spraying')" id="type-spraying"><i class="fas fa-spray-can"></i> Spraying</button>
                  <button class="type-btn" onclick="selectType('harvest')" id="type-harvest"><i class="fas fa-basket-shopping"></i> Harvest</button>
                  <button class="type-btn" onclick="selectType('maintenance')" id="type-maintenance"><i class="fas fa-wrench"></i> Maintenance</button>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Task Name</label>
                <input type="text" class="form-input" id="task-name" placeholder="e.g. Zone A Morning Irrigation" />
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
                <div class="form-group">
                  <label class="form-label">Time</label>
                  <input type="time" class="form-input" id="task-time" value="06:00" />
                </div>
                <div class="form-group">
                  <label class="form-label">Zone</label>
                  <select class="form-select" id="task-zone">
                    <option value="A">Zone A</option>
                    <option value="B">Zone B</option>
                    <option value="C">Zone C</option>
                    <option value="All">All Zones</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">Notes <span style="font-weight:400;text-transform:none;letter-spacing:0;">(optional)</span></label>
                <textarea class="form-textarea" id="task-notes" placeholder="Additional details, duration, amounts..."></textarea>
              </div>
              <div class="btn-row">
                <button class="btn btn-primary" onclick="addEvent()"><i class="fas fa-plus"></i> Add Task</button>
                <button class="btn btn-ghost" onclick="clearForm()"><i class="fas fa-xmark"></i></button>
              </div>
            </div>
          </div>

        </div>
      </div>

    </div>

    <footer style="background:#fff;border-top:1px solid var(--border);padding:20px 32px;display:flex;align-items:center;justify-content:space-between;font-size:0.75rem;color:var(--text-muted);">
      <span>© 2026 Solar IoT Farm System — Schedule Planner</span>
      <span style="color:var(--green-mid);font-weight:600;"><i class="fas fa-calendar-check" style="margin-right:4px;"></i> Tasks saved locally per session</span>
    </footer>
  </div>
</div>

<!-- ══ EDIT MODAL ══ -->
<div class="modal-overlay" id="edit-modal" onclick="handleBackdropClick(event)">
  <div class="modal">
    <div class="modal-head">
      <div class="modal-head-icon" id="modal-type-icon" style="background:var(--water-pale);color:var(--water);">
        <i class="fas fa-pen-to-square"></i>
      </div>
      <div>
        <div class="modal-title">Edit Task</div>
        <div class="modal-subtitle" id="modal-date-label">—</div>
      </div>
      <button class="modal-close" onclick="closeModal()" title="Close"><i class="fas fa-xmark"></i></button>
    </div>
    <div class="modal-body">
      <!-- Task type -->
      <div class="form-group">
        <label class="form-label">Task Type</label>
        <div class="type-selector">
          <button class="type-btn" onclick="selectEditType('irrigation')" id="edit-type-irrigation"><i class="fas fa-droplet"></i> Irrigation</button>
          <button class="type-btn" onclick="selectEditType('spraying')" id="edit-type-spraying"><i class="fas fa-spray-can"></i> Spraying</button>
          <button class="type-btn" onclick="selectEditType('harvest')" id="edit-type-harvest"><i class="fas fa-basket-shopping"></i> Harvest</button>
          <button class="type-btn" onclick="selectEditType('maintenance')" id="edit-type-maintenance"><i class="fas fa-wrench"></i> Maintenance</button>
        </div>
      </div>
      <!-- Name -->
      <div class="form-group">
        <label class="form-label">Task Name</label>
        <input type="text" class="form-input" id="edit-name" placeholder="Task name" />
      </div>
      <!-- Time + Zone -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
        <div class="form-group">
          <label class="form-label">Time</label>
          <input type="time" class="form-input" id="edit-time" />
        </div>
        <div class="form-group">
          <label class="form-label">Zone</label>
          <select class="form-select" id="edit-zone">
            <option value="A">Zone A</option>
            <option value="B">Zone B</option>
            <option value="C">Zone C</option>
            <option value="All">All Zones</option>
          </select>
        </div>
      </div>
      <!-- Reschedule date -->
      <div class="form-group">
        <label class="form-label">Date <span style="font-weight:400;text-transform:none;letter-spacing:0;">(reschedule to a different day)</span></label>
        <input type="date" class="form-input" id="edit-date" />
      </div>
      <!-- Notes -->
      <div class="form-group" style="margin-bottom:0;">
        <label class="form-label">Notes <span style="font-weight:400;text-transform:none;letter-spacing:0;">(optional)</span></label>
        <textarea class="form-textarea" id="edit-notes" placeholder="Additional details, duration, amounts..."></textarea>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-save" onclick="saveEdit()"><i class="fas fa-floppy-disk"></i> Save Changes</button>
      <button class="btn btn-delete" onclick="deleteFromModal()"><i class="fas fa-trash-can"></i> Delete</button>
      <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
    </div>
  </div>
</div>

<script>
  // Clock
  function updateClock() {
    const now = new Date();
    document.getElementById('clock').textContent =
      now.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'}) + ' · ' +
      now.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit',second:'2-digit'});
  }
  updateClock(); setInterval(updateClock, 1000);

  // ── STATE ──
  const now = new Date();
  let calDate     = new Date(now.getFullYear(), now.getMonth(), 1);
  const todayKey = dateKey(now.getFullYear(), now.getMonth(), now.getDate());
  let selectedDate = null;
  let selectedType = 'irrigation';
  let editingKey   = null;
  let editingId    = null;
  let editType     = 'irrigation';

  const events = {
    '2026-03-05': [{id:1,type:'irrigation',name:'Zone A Morning Irrigation',time:'06:00',zone:'A',notes:'40L estimated'}],
    '2026-03-08': [{id:2,type:'spraying',name:'Nutrient Spray — All Zones',time:'06:00',zone:'All',notes:'Weekly application'}],
    '2026-03-12': [
      {id:3,type:'irrigation',name:'Zone B & C Irrigation',time:'06:00',zone:'B',notes:''},
      {id:4,type:'maintenance',name:'Sensor Calibration Check',time:'09:00',zone:'C',notes:'Zone C soil sensor'},
    ],
    '2026-03-15': [{id:5,type:'spraying',name:'Pest Control — Zone A',time:'06:00',zone:'A',notes:'Full coverage'}],
    '2026-03-19': [{id:6,type:'irrigation',name:'Morning Irrigation Cycle',time:'06:00',zone:'All',notes:''}],
    '2026-03-22': [{id:7,type:'spraying',name:'Fungicide Application',time:'07:00',zone:'B',notes:'Preventive treatment'}],
    '2026-03-26': [{id:8,type:'irrigation',name:'Evening Irrigation',time:'18:00',zone:'A',notes:''}],
    '2026-03-28': [{id:9,type:'harvest',name:'First Harvest — Zone A',time:'08:00',zone:'A',notes:'Estimated 200kg yield'}],
  };
  let nextId = 100;

  const typeConfig = {
    irrigation:  {color:'var(--water)',    pale:'var(--water-pale)',  icon:'fa-droplet',         pillClass:'irrigation', badgeClass:'badge-irr', label:'Irrigation'},
    spraying:    {color:'var(--solar)',    pale:'var(--solar-pale)',  icon:'fa-spray-can',       pillClass:'spraying',   badgeClass:'badge-spr', label:'Spraying'},
    harvest:     {color:'var(--red)',      pale:'var(--red-pale)',    icon:'fa-basket-shopping', pillClass:'harvest',    badgeClass:'badge-har', label:'Harvest'},
    maintenance: {color:'var(--green-mid)',pale:'var(--green-pale)', icon:'fa-wrench',          pillClass:'maintenance',badgeClass:'badge-mnt', label:'Maintenance'},
  };

  function dateKey(y, m, d) {
    return y + '-' + String(m+1).padStart(2,'0') + '-' + String(d).padStart(2,'0');
  }

  // ── CALENDAR ──
  function renderCalendar() {
    const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    document.getElementById('cal-month-label').textContent = months[calDate.getMonth()] + ' ' + calDate.getFullYear();
    const grid = document.getElementById('cal-days-grid');
    grid.innerHTML = '';
    const year = calDate.getFullYear(), month = calDate.getMonth();
    const firstDay   = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month+1, 0).getDate();
    const prevDays   = new Date(year, month, 0).getDate();

    for (let i = firstDay - 1; i >= 0; i--) renderCell(grid, prevDays-i, dateKey(year, month-1, prevDays-i), true);
    for (let d = 1; d <= daysInMonth; d++)   renderCell(grid, d, dateKey(year, month, d), false);
    const rem = (firstDay + daysInMonth) % 7;
    if (rem > 0) for (let d = 1; d <= 7-rem; d++) renderCell(grid, d, dateKey(year, month+1, d), true);
  }

  function renderCell(grid, d, key, otherMonth) {
    const cell = document.createElement('div');
    cell.className = 'cal-cell' + (otherMonth ? ' other-month' : '');
    const [cy, cm, cd] = key.split('-').map(Number);
    const todayYear = now.getFullYear();
    const todayMonth = now.getMonth() + 1;
    const todayDay = now.getDate();
    if (cy===todayYear && cm===todayMonth && cd===todayDay && !otherMonth) cell.classList.add('today');
    if (selectedDate === key) cell.classList.add('selected');
    cell.innerHTML = `<div class="cal-cell-day">
      <span>${d}</span>
      ${cy===todayYear&&cm===todayMonth&&cd===todayDay&&!otherMonth ? '<span class="cal-today-dot"></span>' : ''}
    </div>
    <div class="cal-cell-events" id="cell-events-${key}"></div>
    <div class="cal-add-hint">+ Add task</div>`;
    cell.onclick = () => selectDate(key);
    grid.appendChild(cell);
    if (events[key]) {
      const cont = document.getElementById('cell-events-' + key);
      events[key].slice(0,3).forEach(ev => {
        const pill = document.createElement('div');
        pill.className = 'cal-event-pill ' + typeConfig[ev.type].pillClass;
        pill.innerHTML = `<i class="fas ${typeConfig[ev.type].icon}"></i> ${ev.name.length > 16 ? ev.name.slice(0,14)+'…' : ev.name}`;
        cont && cont.appendChild(pill);
      });
      if (events[key].length > 3) {
        const more = document.createElement('div');
        more.className = 'cal-event-pill maintenance';
        more.textContent = `+${events[key].length - 3} more`;
        cont && cont.appendChild(more);
      }
    }
  }

  function selectDate(key) {
    selectedDate = key;
    renderCalendar();
    renderDayPanel();
    const d = new Date(key + 'T00:00:00');
    document.getElementById('add-form-date-label').textContent = d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});
    document.getElementById('selected-day-label').textContent  = d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'});
  }

  function renderDayPanel() {
    const list = document.getElementById('day-events-list');
    const evs  = events[selectedDate] || [];
    document.getElementById('selected-day-count').textContent = evs.length === 0
      ? 'No tasks scheduled'
      : evs.length + ' task' + (evs.length > 1 ? 's' : '') + ' scheduled';

    if (evs.length === 0) {
      list.innerHTML = `<div class="empty-state"><div class="empty-icon">🌱</div>
        <div class="empty-title">No tasks this day</div>
        <div class="empty-desc">Use the form below to schedule irrigation, spraying, or other farm work.</div></div>`;
      return;
    }

    list.innerHTML = '';
    evs.forEach(ev => {
      const cfg  = typeConfig[ev.type];
      const item = document.createElement('div');
      item.className = 'event-item';
      item.innerHTML = `
        <div class="event-dot" style="background:${cfg.color};"></div>
        <div class="event-body">
          <div class="event-title">${ev.name}</div>
          <div class="event-meta">
            <span class="upcoming-badge ${cfg.badgeClass}">${cfg.label}</span>
            &nbsp;Zone ${ev.zone}${ev.notes ? ' · ' + ev.notes : ''}
          </div>
          <div class="event-time"><i class="fas fa-clock" style="margin-right:4px;font-size:0.65rem;"></i>${ev.time}</div>
        </div>
        <div class="event-actions">
          <button class="btn-edit-sm" title="Edit task" onclick="openEditModal('${selectedDate}', ${ev.id})">
            <i class="fas fa-pen"></i>
          </button>
          <button class="btn-danger-sm" title="Delete task" onclick="deleteEvent('${selectedDate}', ${ev.id})">
            <i class="fas fa-trash-can"></i>
          </button>
        </div>`;
      list.appendChild(item);
    });
  }

  function renderUpcoming() {
    const list = document.getElementById('upcoming-list');
    const upcoming = [];
    for (let i = 0; i <= 14; i++) {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i);
      const key = dateKey(d.getFullYear(), d.getMonth(), d.getDate());
      if (events[key]) events[key].forEach(ev => upcoming.push({key, date: d, ev}));
    }
    upcoming.sort((a,b) => a.key.localeCompare(b.key) || a.ev.time.localeCompare(b.ev.time));
    document.getElementById('upcoming-count').textContent = 'Next 14 days · ' + upcoming.length + ' task' + (upcoming.length !== 1 ? 's' : '');

    if (upcoming.length === 0) {
      list.innerHTML = `<div class="empty-state"><div class="empty-icon">📆</div><div class="empty-title">No upcoming tasks</div><div class="empty-desc">Schedule your first task above.</div></div>`;
      return;
    }

    list.innerHTML = '';
    upcoming.forEach(({key, date, ev}) => {
      const cfg = typeConfig[ev.type];
      const dayLabel = key === todayKey ? 'Today' : date.toLocaleDateString('en-US',{month:'short',day:'numeric'});
      const item = document.createElement('div');
      item.className = 'upcoming-item';
      item.innerHTML = `
        <div class="event-dot" style="background:${cfg.color};flex-shrink:0;"></div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:0.84rem;font-weight:700;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${ev.name}</div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:2px;">${dayLabel} · ${ev.time} · Zone ${ev.zone}</div>
        </div>
        <div style="display:flex;gap:5px;align-items:center;flex-shrink:0;">
          <span class="upcoming-badge ${cfg.badgeClass}">${cfg.label}</span>
          <button class="btn-edit-sm" style="padding:4px 8px;font-size:0.7rem;" title="Edit" onclick="openEditModal('${key}', ${ev.id})">
            <i class="fas fa-pen"></i>
          </button>
        </div>`;
      list.appendChild(item);
    });
  }

  // ── ADD ──
  function selectType(type) {
    selectedType = type;
    document.querySelectorAll('#add-event-card .type-btn, .detail-card .type-btn').forEach(b => {
      if (b.id && b.id.startsWith('type-')) b.className = 'type-btn';
    });
    document.getElementById('type-' + type).className = 'type-btn selected-' + type;
  }

  function addEvent() {
    if (!selectedDate) { alert('Please select a date on the calendar first.'); return; }
    const name = document.getElementById('task-name').value.trim();
    if (!name) { document.getElementById('task-name').focus(); return; }
    const time  = document.getElementById('task-time').value || '06:00';
    const zone  = document.getElementById('task-zone').value;
    const notes = document.getElementById('task-notes').value.trim();
    if (!events[selectedDate]) events[selectedDate] = [];
    events[selectedDate].push({id: nextId++, type: selectedType, name, time, zone, notes});
    events[selectedDate].sort((a,b) => a.time.localeCompare(b.time));
    clearForm();
    renderCalendar(); renderDayPanel(); renderUpcoming();
  }

  function deleteEvent(key, id) {
    if (!events[key]) return;
    events[key] = events[key].filter(e => e.id !== id);
    if (events[key].length === 0) delete events[key];
    renderCalendar(); renderDayPanel(); renderUpcoming();
  }

  function clearForm() {
    document.getElementById('task-name').value  = '';
    document.getElementById('task-time').value  = '06:00';
    document.getElementById('task-zone').value  = 'A';
    document.getElementById('task-notes').value = '';
  }

  function changeMonth(d) { calDate.setMonth(calDate.getMonth() + d); renderCalendar(); }
  function goToday() { calDate = new Date(now.getFullYear(), now.getMonth(), 1); selectDate(todayKey); }

  // ── EDIT MODAL ──
  function openEditModal(key, id) {
    const ev = (events[key] || []).find(e => e.id === id);
    if (!ev) return;
    editingKey = key;
    editingId  = id;
    editType   = ev.type;

    document.getElementById('edit-name').value  = ev.name;
    document.getElementById('edit-time').value  = ev.time;
    document.getElementById('edit-zone').value  = ev.zone;
    document.getElementById('edit-date').value  = key;
    document.getElementById('edit-notes').value = ev.notes || '';

    selectEditType(ev.type);

    const d = new Date(key + 'T00:00:00');
    document.getElementById('modal-date-label').textContent =
      d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});

    document.getElementById('edit-modal').classList.add('open');
    document.body.style.overflow = 'hidden';
    setTimeout(() => document.getElementById('edit-name').focus(), 300);
  }

  function closeModal() {
    document.getElementById('edit-modal').classList.remove('open');
    document.body.style.overflow = '';
    editingKey = null; editingId = null;
  }

  function handleBackdropClick(e) {
    if (e.target === document.getElementById('edit-modal')) closeModal();
  }

  function selectEditType(type) {
    editType = type;
    const cfg = typeConfig[type];
    ['irrigation','spraying','harvest','maintenance'].forEach(t => {
      document.getElementById('edit-type-' + t).className = 'type-btn' + (t === type ? ' selected-' + type : '');
    });
   
    const icon = document.getElementById('modal-type-icon');
    icon.style.background = cfg.pale;
    icon.style.color = cfg.color;
  }

  function saveEdit() {
    if (editingKey === null || editingId === null) return;
    const name = document.getElementById('edit-name').value.trim();
    if (!name) { document.getElementById('edit-name').focus(); return; }
    const time     = document.getElementById('edit-time').value || '06:00';
    const zone     = document.getElementById('edit-zone').value;
    const notes    = document.getElementById('edit-notes').value.trim();
    const newDate  = document.getElementById('edit-date').value || editingKey;

    events[editingKey] = (events[editingKey] || []).filter(e => e.id !== editingId);
    if (events[editingKey] && events[editingKey].length === 0) delete events[editingKey];

    if (!events[newDate]) events[newDate] = [];
    events[newDate].push({id: editingId, type: editType, name, time, zone, notes});
    events[newDate].sort((a,b) => a.time.localeCompare(b.time));

    if (newDate !== editingKey) {
      const [py, pm] = newDate.split('-').map(Number);
      calDate = new Date(py, pm-1, 1);
      selectedDate = newDate;
    }

    closeModal();
    renderCalendar(); renderDayPanel(); renderUpcoming();
  }

  function deleteFromModal() {
    if (editingKey === null || editingId === null) return;
    deleteEvent(editingKey, editingId);
    closeModal();
  }

  document.addEventListener('keydown', e => {
    if (!document.getElementById('edit-modal').classList.contains('open')) return;
    if (e.key === 'Escape') closeModal();
    if (e.key === 'Enter' && e.ctrlKey) saveEdit();
  });

  selectType('irrigation');
  renderCalendar();
  // Auto-select today on load
  selectDate(todayKey);
  renderUpcoming();

  const preselectDate = '<?= $preselect_date ?>';
  if (preselectDate) {
    const [py, pm] = preselectDate.split('-').map(Number);
    calDate = new Date(py, pm-1, 1);
    renderCalendar();
    selectDate(preselectDate);
  }

  document.addEventListener('click', e => {
    const sidebar = document.getElementById('sidebar');
    if (sidebar && !sidebar.contains(e.target) && !e.target.closest('.mobile-toggle')) sidebar.classList.remove('open');
  });
</script>
</body>
</html>